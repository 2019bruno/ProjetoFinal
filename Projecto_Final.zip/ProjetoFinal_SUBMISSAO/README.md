# ProjetoFinal — Plataforma Web de Monitorização do Centro de Dados

Protótipo full‑stack (Front‑End + Back‑End) alinhado com a Tarefa 5.1:
- Entidades: Utilizador, AtivoMonitorizado, Métrica, Alerta, Incidente
- Casos de uso: UC1..UC6 (Autenticação, Ativos, Métricas/Alertas via API, Dashboard, Incidentes)

## Requisitos
- Node.js 18+ (recomendado)
- NPM

## 1) Backend (API REST)
### Instalação
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

A API fica em: http://localhost:3000

### Utilizadores de teste (criados automaticamente)
- admin@local / Admin123!  (perfil: administrador)
- tecnico@local / Tecnico123! (perfil: tecnico)

## 2) Frontend
Abrir no browser:
- `frontend/index.html`
ou ir direto para:
- `frontend/pages/login.html`

O frontend chama a API por defeito em `http://localhost:3000`.
Se precisares mudar, faz isso no ecrã de login.

## 3) Simular Métricas e Alertas (UC3)
> Nota: estes endpoints não exigem token para facilitar a simulação do “agente de monitorização”.

### Criar um Ativo primeiro (com admin)
No site, entra como admin e cria um ativo.

### Enviar métrica
```bash
curl -X POST http://localhost:3000/api/metricas \
  -H "Content-Type: application/json" \
  -d '{"tipo":"temperatura","valor":27.5,"ativo_id":1}'
```

### Enviar alerta
```bash
curl -X POST http://localhost:3000/api/alertas \
  -H "Content-Type: application/json" \
  -d '{"severidade":"warning","descricao":"Temperatura elevada no rack","ativo_id":1}'
```

## 4) Incidentes (UC5 e UC6)
- Em **Alertas**, clica **Criar Incidente**
- Em **Incidentes**, muda estado para **em_tratamento** ou **concluido**.

## Estrutura
- `backend/` Node.js + Express + SQLite
- `frontend/` HTML/CSS/JS (fetch à API)

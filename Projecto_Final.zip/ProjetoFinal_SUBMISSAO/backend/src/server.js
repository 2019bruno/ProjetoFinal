require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');

const { initDb } = require('./models/init');

const authRoutes = require('./routes/auth.routes');
const ativosRoutes = require('./routes/ativos.routes');
const metricasRoutes = require('./routes/metricas.routes');
const alertasRoutes = require('./routes/alertas.routes');
const incidentesRoutes = require('./routes/incidentes.routes');
const dashboardRoutes = require('./routes/dashboard.routes');
const usersRoutes = require('./routes/users.routes');
const logsRoutes = require('./routes/logs.routes');

const app = express();

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

app.get('/', (req, res) => {
  res.json({ ok: true, name: 'ProjetoFinal API', version: '1.0.0' });
});

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/ativos', ativosRoutes);
app.use('/api/metricas', metricasRoutes);
app.use('/api/alertas', alertasRoutes);
app.use('/api/incidentes', incidentesRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/logs', logsRoutes);

// 404
app.use((req, res) => {
  res.status(404).json({ error: 'Rota não encontrada' });
});

const PORT = process.env.PORT || 3000;

initDb()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`API a correr em http://localhost:${PORT}`);
      console.log('Utilizadores de teste:');
      console.log(' - admin@local / Admin123!');
      console.log(' - tecnico@local / Tecnico123!');
    });
  })
  .catch((e) => {
    console.error('Falha a iniciar BD:', e);
    process.exit(1);
  });

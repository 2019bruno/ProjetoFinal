const db = require('../config/db');
const bcrypt = require('bcryptjs');

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) return reject(err);
      resolve(this);
    });
  });
}

function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) return reject(err);
      resolve(row);
    });
  });
}

async function initDb() {
  await run(`CREATE TABLE IF NOT EXISTS utilizador (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    perfil TEXT NOT NULL CHECK(perfil IN ('administrador','tecnico'))
  );`);

  await run(`CREATE TABLE IF NOT EXISTS ativo_monitorizado (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    tipo TEXT NOT NULL CHECK(tipo IN ('servidor','ups','climatizacao','link')),
    localizacao TEXT NOT NULL,
    criticidade TEXT NOT NULL CHECK(criticidade IN ('baixa','media','alta','critica'))
  );`);

  await run(`CREATE TABLE IF NOT EXISTS metrica (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tipo TEXT NOT NULL CHECK(tipo IN ('temperatura','carga','disponibilidade')),
    valor REAL NOT NULL,
    timestamp TEXT NOT NULL,
    ativo_id INTEGER NOT NULL,
    FOREIGN KEY (ativo_id) REFERENCES ativo_monitorizado(id) ON DELETE CASCADE
  );`);

  await run(`CREATE TABLE IF NOT EXISTS alerta (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    severidade TEXT NOT NULL CHECK(severidade IN ('informativo','warning','critico')),
    descricao TEXT NOT NULL,
    data TEXT NOT NULL,
    ativo_id INTEGER NOT NULL,
    FOREIGN KEY (ativo_id) REFERENCES ativo_monitorizado(id) ON DELETE CASCADE
  );`);


  await run(`CREATE TABLE IF NOT EXISTS log_auditoria (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    acao TEXT NOT NULL,
    detalhe TEXT NOT NULL,
    data TEXT NOT NULL,
    utilizador_id INTEGER,
    FOREIGN KEY (utilizador_id) REFERENCES utilizador(id) ON DELETE SET NULL
  );`);


  await run(`CREATE TABLE IF NOT EXISTS incidente (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    estado TEXT NOT NULL CHECK(estado IN ('aberto','em_tratamento','concluido')),
    descricao TEXT NOT NULL,
    data_abertura TEXT NOT NULL,
    data_fecho TEXT,
    alerta_id INTEGER NOT NULL UNIQUE,
    utilizador_id INTEGER NOT NULL,
    FOREIGN KEY (alerta_id) REFERENCES alerta(id) ON DELETE CASCADE,
    FOREIGN KEY (utilizador_id) REFERENCES utilizador(id) ON DELETE SET NULL
  );`);

  // Seed: criar 2 utilizadores se ainda não existirem
  const admin = await get(`SELECT id FROM utilizador WHERE email = ?`, ['admin@local']);
  if (!admin) {
    const adminHash = await bcrypt.hash('Admin123!', 10);
    await run(`INSERT INTO utilizador (nome,email,password_hash,perfil) VALUES (?,?,?,?)`,
      ['Administrador', 'admin@local', adminHash, 'administrador']
    );
  }

  const tecnico = await get(`SELECT id FROM utilizador WHERE email = ?`, ['tecnico@local']);
  if (!tecnico) {
    const techHash = await bcrypt.hash('Tecnico123!', 10);
    await run(`INSERT INTO utilizador (nome,email,password_hash,perfil) VALUES (?,?,?,?)`,
      ['Técnico', 'tecnico@local', techHash, 'tecnico']
    );
  }
}

module.exports = { initDb };

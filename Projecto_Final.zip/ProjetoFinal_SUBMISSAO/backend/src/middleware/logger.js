const { run } = require('../routes/_dbhelpers');

async function logAcao(acao, detalhe, utilizador_id = null) {
  const now = new Date().toISOString();
  try {
    await run(
      `INSERT INTO log_auditoria (acao, detalhe, data, utilizador_id) VALUES (?,?,?,?)`,
      [acao, detalhe, now, utilizador_id]
    );
  } catch (e) {
    console.error('Falha ao gravar log:', e.message);
  }
}

module.exports = { logAcao };

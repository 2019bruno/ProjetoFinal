const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const DB_PATH = process.env.DB_PATH || './database.sqlite';
const resolvedPath = path.isAbsolute(DB_PATH) ? DB_PATH : path.join(process.cwd(), DB_PATH);

const db = new sqlite3.Database(resolvedPath, (err) => {
  if (err) {
    console.error('Erro ao abrir a base de dados:', err.message);
  } else {
    console.log('Base de dados ligada:', resolvedPath);
  }
});

db.run('PRAGMA foreign_keys = ON;');

module.exports = db;

const express = require('express');
const { authRequired, requireRole } = require('../middleware/auth');
const { all } = require('./_dbhelpers');

const router = express.Router();

router.get('/', authRequired, requireRole('administrador'), async (req, res) => {
  try {
    const rows = await all(`
      SELECT l.*, u.nome AS utilizador_nome, u.email AS utilizador_email
      FROM log_auditoria l
      LEFT JOIN utilizador u ON u.id = l.utilizador_id
      ORDER BY datetime(l.data) DESC
      LIMIT 200
    `);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao listar logs', details: e.message });
  }
});

module.exports = router;

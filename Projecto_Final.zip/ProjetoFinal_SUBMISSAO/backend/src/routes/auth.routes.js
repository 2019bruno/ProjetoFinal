const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { get, run } = require('./_dbhelpers');

const router = express.Router();

/**
 * POST /api/auth/login
 * body: { email, password }
 */
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) return res.status(400).json({ error: 'email e password são obrigatórios' });

    const user = await get(`SELECT id, nome, email, password_hash, perfil FROM utilizador WHERE email = ?`, [email]);
    if (!user) return res.status(401).json({ error: 'Credenciais inválidas' });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'Credenciais inválidas' });

    const token = jwt.sign(
      { id: user.id, nome: user.nome, email: user.email, perfil: user.perfil },
      process.env.JWT_SECRET,
      { expiresIn: '8h' }
    );

    res.json({ token, user: { id: user.id, nome: user.nome, email: user.email, perfil: user.perfil } });
  } catch (e) {
    res.status(500).json({ error: 'Erro no login', details: e.message });
  }
});

/**
 * POST /api/auth/register
 * body: { nome, email, password, perfil }
 * Nota: Para protótipo. Podes desativar se o professor não quiser registos livres.
 */
router.post('/register', async (req, res) => {
  try {
    const { nome, email, password, perfil } = req.body || {};
    if (!nome || !email || !password || !perfil) {
      return res.status(400).json({ error: 'nome, email, password e perfil são obrigatórios' });
    }
    if (!['administrador','tecnico'].includes(perfil)) {
      return res.status(400).json({ error: 'perfil inválido' });
    }

    const existing = await get(`SELECT id FROM utilizador WHERE email = ?`, [email]);
    if (existing) return res.status(409).json({ error: 'Email já existe' });

    const hash = await bcrypt.hash(password, 10);
    const r = await run(`INSERT INTO utilizador (nome,email,password_hash,perfil) VALUES (?,?,?,?)`,
      [nome, email, hash, perfil]
    );
    res.status(201).json({ id: r.lastID, nome, email, perfil });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao registar utilizador', details: e.message });
  }
});

module.exports = router;

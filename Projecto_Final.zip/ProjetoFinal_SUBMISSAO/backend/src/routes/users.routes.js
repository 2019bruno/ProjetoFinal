const express = require('express');
const bcrypt = require('bcryptjs');
const { authRequired, requireRole } = require('../middleware/auth');
const { all, get, run } = require('./_dbhelpers');
const { logAcao } = require('../middleware/logger');

const router = express.Router();

router.get('/', authRequired, requireRole('administrador'), async (req, res) => {
  try {
    const rows = await all(`SELECT id, nome, email, perfil FROM utilizador ORDER BY id DESC`);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao listar utilizadores', details: e.message });
  }
});

router.post('/', authRequired, requireRole('administrador'), async (req, res) => {
  try {
    const { nome, email, password, perfil } = req.body || {};
    if (!nome || !email || !password || !perfil) {
      return res.status(400).json({ error: 'nome, email, password e perfil são obrigatórios' });
    }
    if (!['administrador','tecnico'].includes(perfil)) {
      return res.status(400).json({ error: 'perfil inválido' });
    }

    const exists = await get(`SELECT id FROM utilizador WHERE email=?`, [email]);
    if (exists) return res.status(409).json({ error: 'Email já existe' });

    const hash = await bcrypt.hash(password, 10);
    const r = await run(
      `INSERT INTO utilizador (nome,email,password_hash,perfil) VALUES (?,?,?,?)`,
      [nome, email, hash, perfil]
    );

    await logAcao('CRIAR_UTILIZADOR', `Criado utilizador ${email} (${perfil})`, req.user.id);
    res.status(201).json({ id: r.lastID, nome, email, perfil });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao criar utilizador', details: e.message });
  }
});

router.delete('/:id', authRequired, requireRole('administrador'), async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (id === req.user.id) return res.status(400).json({ error: 'Não podes remover o teu próprio utilizador' });

    const exists = await get(`SELECT id, email FROM utilizador WHERE id=?`, [id]);
    if (!exists) return res.status(404).json({ error: 'Utilizador não encontrado' });

    await run(`DELETE FROM utilizador WHERE id=?`, [id]);
    await logAcao('REMOVER_UTILIZADOR', `Removido utilizador ${exists.email}`, req.user.id);

    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao remover utilizador', details: e.message });
  }
});

module.exports = router;

const express = require('express');
const { authRequired } = require('../middleware/auth');
const { all, get, run } = require('./_dbhelpers');

const router = express.Router();

// POST /api/metricas (agente simulado)
router.post('/', async (req, res) => {
  try {
    const { tipo, valor, timestamp, ativo_id } = req.body || {};
    if (!tipo || valor === undefined || !ativo_id) {
      return res.status(400).json({ error: 'tipo, valor e ativo_id são obrigatórios' });
    }
    if (!['temperatura','carga','disponibilidade'].includes(tipo)) return res.status(400).json({ error: 'tipo inválido' });

    const ativo = await get(`SELECT id FROM ativo_monitorizado WHERE id = ?`, [ativo_id]);
    if (!ativo) return res.status(404).json({ error: 'Ativo não encontrado' });

    const ts = timestamp || new Date().toISOString();
    const r = await run(`INSERT INTO metrica (tipo, valor, timestamp, ativo_id) VALUES (?,?,?,?)`,
      [tipo, Number(valor), ts, ativo_id]
    );
    res.status(201).json({ id: r.lastID, tipo, valor: Number(valor), timestamp: ts, ativo_id });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao registar métrica', details: e.message });
  }
});

// GET /api/metricas?ativo_id=1&limit=50 (autenticado)
router.get('/', authRequired, async (req, res) => {
  try {
    const ativoId = req.query.ativo_id ? Number(req.query.ativo_id) : null;
    const limit = req.query.limit ? Math.min(200, Number(req.query.limit)) : 50;

    let sql = `SELECT * FROM metrica`;
    const params = [];
    if (ativoId) {
      sql += ` WHERE ativo_id = ?`;
      params.push(ativoId);
    }
    sql += ` ORDER BY datetime(timestamp) DESC LIMIT ?`;
    params.push(limit);

    const rows = await all(sql, params);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao listar métricas', details: e.message });
  }
});

module.exports = router;

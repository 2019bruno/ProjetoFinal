const express = require('express');
const { authRequired } = require('../middleware/auth');
const { all, get, run } = require('./_dbhelpers');

const router = express.Router();

// POST /api/alertas (agente simulado)
router.post('/', async (req, res) => {
  try {
    const { severidade, descricao, data, ativo_id } = req.body || {};
    if (!severidade || !descricao || !ativo_id) {
      return res.status(400).json({ error: 'severidade, descricao e ativo_id são obrigatórios' });
    }
    if (!['informativo','warning','critico'].includes(severidade)) return res.status(400).json({ error: 'severidade inválida' });

    const ativo = await get(`SELECT id FROM ativo_monitorizado WHERE id = ?`, [ativo_id]);
    if (!ativo) return res.status(404).json({ error: 'Ativo não encontrado' });

    const dt = data || new Date().toISOString();
    const r = await run(`INSERT INTO alerta (severidade, descricao, data, ativo_id) VALUES (?,?,?,?)`,
      [severidade, descricao, dt, ativo_id]
    );
    res.status(201).json({ id: r.lastID, severidade, descricao, data: dt, ativo_id });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao registar alerta', details: e.message });
  }
});

// GET /api/alertas?ativo_id=1 (autenticado)
router.get('/', authRequired, async (req, res) => {
  try {
    const ativoId = req.query.ativo_id ? Number(req.query.ativo_id) : null;
    let sql = `SELECT a.*, am.nome AS ativo_nome, am.tipo AS ativo_tipo
               FROM alerta a
               JOIN ativo_monitorizado am ON am.id = a.ativo_id`;
    const params = [];
    if (ativoId) {
      sql += ` WHERE a.ativo_id = ?`;
      params.push(ativoId);
    }
    sql += ` ORDER BY datetime(a.data) DESC`;
    const rows = await all(sql, params);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao listar alertas', details: e.message });
  }
});

module.exports = router;

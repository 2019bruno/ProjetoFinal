const express = require('express');
const { authRequired } = require('../middleware/auth');
const { all, get, run } = require('./_dbhelpers');
const { logAcao } = require('../middleware/logger');

const router = express.Router();

// POST /api/incidentes/from-alerta/:alertaId  (criar incidente a partir de alerta)
router.post('/from-alerta/:alertaId', authRequired, async (req, res) => {
  try {
    const alertaId = Number(req.params.alertaId);
    const alerta = await get(`SELECT * FROM alerta WHERE id = ?`, [alertaId]);
    if (!alerta) return res.status(404).json({ error: 'Alerta não encontrado' });

    const exists = await get(`SELECT id FROM incidente WHERE alerta_id = ?`, [alertaId]);
    if (exists) return res.status(409).json({ error: 'Já existe um incidente para este alerta' });

    const descricao = req.body?.descricao || `Incidente criado a partir do alerta #${alertaId}: ${alerta.descricao}`;
    const now = new Date().toISOString();

    const r = await run(
      `INSERT INTO incidente (estado, descricao, data_abertura, data_fecho, alerta_id, utilizador_id)
       VALUES (?,?,?,?,?,?)`,
      ['aberto', descricao, now, null, alertaId, req.user.id]
    );

    const created = await get(`SELECT * FROM incidente WHERE id = ?`, [r.lastID]);
        await logAcao('CRIAR_INCIDENTE', `Criado incidente a partir do alerta ${alertaId}`, req.user.id);
    res.status(201).json(created);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao criar incidente', details: e.message });
  }
});

// GET /api/incidentes?estado=aberto
router.get('/', authRequired, async (req, res) => {
  try {
    const estado = req.query.estado || null;

    let sql = `SELECT i.*, a.severidade, a.descricao AS alerta_descricao, a.data AS alerta_data,
                      am.nome AS ativo_nome, am.tipo AS ativo_tipo,
                      u.nome AS tecnico_nome
               FROM incidente i
               JOIN alerta a ON a.id = i.alerta_id
               JOIN ativo_monitorizado am ON am.id = a.ativo_id
               LEFT JOIN utilizador u ON u.id = i.utilizador_id`;
    const params = [];
    if (estado) {
      sql += ` WHERE i.estado = ?`;
      params.push(estado);
    }
    sql += ` ORDER BY datetime(i.data_abertura) DESC`;

    const rows = await all(sql, params);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao listar incidentes', details: e.message });
  }
});

// PUT /api/incidentes/:id  (atualizar / encerrar)
router.put('/:id', authRequired, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const current = await get(`SELECT * FROM incidente WHERE id = ?`, [id]);
    if (!current) return res.status(404).json({ error: 'Incidente não encontrado' });

    const estado = req.body?.estado ?? current.estado;
    const descricao = req.body?.descricao ?? current.descricao;

    if (!['aberto','em_tratamento','concluido'].includes(estado)) {
      return res.status(400).json({ error: 'estado inválido' });
    }

    let data_fecho = current.data_fecho;
    if (estado === 'concluido' && !data_fecho) data_fecho = new Date().toISOString();
    if (estado !== 'concluido') data_fecho = null;

    await run(`UPDATE incidente SET estado=?, descricao=?, data_fecho=? WHERE id=?`,
      [estado, descricao, data_fecho, id]
    );

    const updated = await get(`SELECT * FROM incidente WHERE id = ?`, [id]);
        await logAcao('ATUALIZAR_INCIDENTE', `Atualizado incidente ${id} para estado ${estado}`, req.user.id);
    res.json(updated);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao atualizar incidente', details: e.message });
  }
});

module.exports = router;

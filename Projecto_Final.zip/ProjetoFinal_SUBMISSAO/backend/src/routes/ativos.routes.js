const express = require('express');
const { authRequired, requireRole } = require('../middleware/auth');
const { all, get, run } = require('./_dbhelpers');
const { logAcao } = require('../middleware/logger');

const router = express.Router();

// GET /api/ativos
router.get('/', authRequired, async (req, res) => {
  try {
    const rows = await all(`SELECT * FROM ativo_monitorizado ORDER BY id DESC`);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao listar ativos', details: e.message });
  }
});

// POST /api/ativos (admin)
router.post('/', authRequired, requireRole('administrador'), async (req, res) => {
  try {
    const { nome, tipo, localizacao, criticidade } = req.body || {};
    if (!nome || !tipo || !localizacao || !criticidade) {
      return res.status(400).json({ error: 'nome, tipo, localizacao e criticidade são obrigatórios' });
    }
    if (!['servidor','ups','climatizacao','link'].includes(tipo)) return res.status(400).json({ error: 'tipo inválido' });
    if (!['baixa','media','alta','critica'].includes(criticidade)) return res.status(400).json({ error: 'criticidade inválida' });

    const r = await run(
      `INSERT INTO ativo_monitorizado (nome,tipo,localizacao,criticidade) VALUES (?,?,?,?)`,
      [nome, tipo, localizacao, criticidade]
    );
    const created = await get(`SELECT * FROM ativo_monitorizado WHERE id = ?`, [r.lastID]);
        await logAcao('CRIAR_ATIVO', `Criado ativo ${created.nome} (${created.tipo})`, req.user.id);
    res.status(201).json(created);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao criar ativo', details: e.message });
  }
});

// PUT /api/ativos/:id (admin)
router.put('/:id', authRequired, requireRole('administrador'), async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { nome, tipo, localizacao, criticidade } = req.body || {};
    const current = await get(`SELECT * FROM ativo_monitorizado WHERE id = ?`, [id]);
    if (!current) return res.status(404).json({ error: 'Ativo não encontrado' });

    const n = nome ?? current.nome;
    const t = tipo ?? current.tipo;
    const l = localizacao ?? current.localizacao;
    const c = criticidade ?? current.criticidade;

    if (!['servidor','ups','climatizacao','link'].includes(t)) return res.status(400).json({ error: 'tipo inválido' });
    if (!['baixa','media','alta','critica'].includes(c)) return res.status(400).json({ error: 'criticidade inválida' });

    await run(`UPDATE ativo_monitorizado SET nome=?, tipo=?, localizacao=?, criticidade=? WHERE id=?`,
      [n, t, l, c, id]
    );
    const updated = await get(`SELECT * FROM ativo_monitorizado WHERE id = ?`, [id]);
    res.json(updated);
  } catch (e) {
    res.status(500).json({ error: 'Erro ao atualizar ativo', details: e.message });
  }
});

// DELETE /api/ativos/:id (admin)
router.delete('/:id', authRequired, requireRole('administrador'), async (req, res) => {
  try {
    const id = Number(req.params.id);
    const current = await get(`SELECT * FROM ativo_monitorizado WHERE id = ?`, [id]);
    if (!current) return res.status(404).json({ error: 'Ativo não encontrado' });

    await run(`DELETE FROM ativo_monitorizado WHERE id = ?`, [id]);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao remover ativo', details: e.message });
  }
});

module.exports = router;

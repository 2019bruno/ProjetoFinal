const express = require('express');
const { authRequired } = require('../middleware/auth');
const { get, all } = require('./_dbhelpers');

const router = express.Router();

router.get('/summary', authRequired, async (req, res) => {
  try {
    const ativos = await get(`SELECT COUNT(*) as total FROM ativo_monitorizado`);
    const ativosPorTipo = await all(`SELECT tipo, COUNT(*) as total FROM ativo_monitorizado GROUP BY tipo`);
    const alertas24 = await get(`SELECT COUNT(*) as total FROM alerta WHERE datetime(data) >= datetime('now','-1 day')`);
    const incAbertos = await get(`SELECT COUNT(*) as total FROM incidente WHERE estado='aberto'`);
    const incTrat = await get(`SELECT COUNT(*) as total FROM incidente WHERE estado='em_tratamento'`);
    const incConcl = await get(`SELECT COUNT(*) as total FROM incidente WHERE estado='concluido'`);

    const ultimosAlertas = await all(`
      SELECT a.id, a.severidade, a.descricao, a.data, am.nome AS ativo_nome
      FROM alerta a JOIN ativo_monitorizado am ON am.id = a.ativo_id
      ORDER BY datetime(a.data) DESC LIMIT 5
    `);

    const ultimosIncidentes = await all(`
      SELECT i.id, i.estado, i.data_abertura, am.nome AS ativo_nome
      FROM incidente i
      JOIN alerta a ON a.id = i.alerta_id
      JOIN ativo_monitorizado am ON am.id = a.ativo_id
      ORDER BY datetime(i.data_abertura) DESC LIMIT 5
    `);

    res.json({
      ativos: ativos.total,
      ativos_por_tipo: ativosPorTipo,
      alertas_ultimas_24h: alertas24.total,
      incidentes: { abertos: incAbertos.total, em_tratamento: incTrat.total, concluidos: incConcl.total },
      ultimos_alertas: ultimosAlertas,
      ultimos_incidentes: ultimosIncidentes
    });
  } catch (e) {
    res.status(500).json({ error: 'Erro no dashboard', details: e.message });
  }
});

module.exports = router;

function renderHeader(active){
  const hdr = document.querySelector('header');
  if (!hdr) return;
  const token = localStorage.getItem('token');
  hdr.innerHTML = `
    <div>
      <strong>ProjetoFinal</strong>
      <span class="small" style="margin-left:10px;">Monitorização do Centro de Dados</span>
    </div>
    <nav>
      ${token ? `
        <a href="./dashboard.html" ${active==='dashboard'?'style="text-decoration:underline"':''}>Dashboard</a>
        <a href="./ativos.html" ${active==='ativos'?'style="text-decoration:underline"':''}>Ativos</a>
        <a href="./alertas.html" ${active==='alertas'?'style="text-decoration:underline"':''}>Alertas</a>
        <a href="./incidentes.html" ${active==='incidentes'?'style="text-decoration:underline"':''}>Incidentes</a>
        <a href="./metricas.html">Métricas</a>
        <a href="./users.html">Utilizadores</a>
        <a href="./logs.html">Logs</a>
        <a href="#" onclick="logout();return false;">Sair</a>
      ` : `
        <a href="./login.html">Login</a>
      `}
    </nav>
  `;
}

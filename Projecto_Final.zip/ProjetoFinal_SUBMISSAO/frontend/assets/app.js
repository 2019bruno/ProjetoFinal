const API_BASE = localStorage.getItem('API_BASE') || 'http://localhost:3000';

function setApiBase(url){
  localStorage.setItem('API_BASE', url);
}

function getToken(){
  return localStorage.getItem('token');
}
function setToken(t){
  localStorage.setItem('token', t);
}
function clearToken(){
  localStorage.removeItem('token');
}

async function api(path, opts = {}){
  const headers = opts.headers || {};
  headers['Content-Type'] = 'application/json';

  const token = getToken();
  if (token) headers['Authorization'] = 'Bearer ' + token;

  const res = await fetch(API_BASE + path, { ...opts, headers });
  const data = await res.json().catch(()=> ({}));
  if (!res.ok) throw new Error(data.error || ('Erro HTTP ' + res.status));
  return data;
}

function requireAuth(){
  if (!getToken()){
    window.location.href = './login.html';
  }
}

function logout(){
  clearToken();
  window.location.href = './login.html';
}

function qs(id){ return document.getElementById(id); }

function fmtDate(iso){
  if (!iso) return '';
  try { return new Date(iso).toLocaleString(); } catch { return iso; }
}

# Relatório Final — ProjetoFinal (Tarefa 5.2)

**Aluno:** Bruno Manuel

## Conteúdo da entrega
- Aplicação Web (Front-End + Back-End)
- API REST
- Base de Dados SQLite
- UC1–UC6 + melhorias (Utilizadores, Logs de Auditoria, Página de Métricas e Dashboard enriquecido)

## Como executar

### Backend
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

### Frontend
Abrir no navegador:
- `frontend/index.html` (ou `frontend/pages/login.html`)

## Credenciais
- admin@local / Admin123!
- tecnico@local / Tecnico123!

ProjetoFinal — Submissão (Tarefa 5.2)

Este trabalho é a continuação direta da Tarefa 5.1 e implementa UC1–UC6.

Como executar:
1) Backend:
   cd backend
   npm install
   npm run dev

2) Frontend:
   abrir frontend/index.html

Credenciais:
- admin@local / Admin123!
- tecnico@local / Tecnico123!
